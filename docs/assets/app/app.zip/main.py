# -*- coding: utf-8 -*-
"""
RadioUnlock — Free Car Radio Code Calculator
Flet mobile/web app. Runs as Android APK, iOS app, or web browser.

Run locally:
  cd app
  flet run                          # desktop
  flet run --web                    # web browser
  flet run --android --debug        # android (requires Android SDK)

Build APK:
  flet pack --android app/main.py
"""

import flet as ft
from flet import (
    AppView, Column, Container, ElevatedButton, Text,
    TextField, Row, Icon, View, Page, OutlinedButton
)
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from radiocodes.algorithms import (
    FordMAlgorithm, FordVAlgorithm, RenaultAlgorithm,
    VWRCDAlgorithm, VauxhallAlgorithm, FiatAlgorithm,
    NissanAlgorithm, HondaAlgorithm, KiaAlgorithm
)
from radiocodes.lookup_engine import load_csv, get_stats

# Load database
load_csv()
STATS = get_stats()
DB_TOTAL = STATS["total_pairs"]
DB_BRANDS = len(STATS["brands"])

# Algorithm registry
ALGORITHMS = {
    "Ford M-Series": FordMAlgorithm(),
    "Ford V-Series": FordVAlgorithm(),
    "Renault / Dacia": RenaultAlgorithm(),
    "Kia": KiaAlgorithm(),
    "VW / Audi / Seat / Skoda": VWRCDAlgorithm(),
    "Vauxhall / Opel": VauxhallAlgorithm(),
    "Fiat / Alfa Romeo": FiatAlgorithm(),
    "Nissan": NissanAlgorithm(),
    "Honda": HondaAlgorithm(),
    "Acura": HondaAlgorithm(),
}

# Brand display config: (label, emoji, color, status_note)
BRAND_META = {
    "Ford M-Series":     ("Ford M-Series",      "📻", "#238636", "✅ Instant"),
    "Ford V-Series":     ("Ford V-Series",      "📻", "#238636", "✅ Instant"),
    "Renault / Dacia":   ("Renault / Dacia",    "🔴", "#238636", "✅ Instant"),
    "Kia":               ("Kia",                "🟢", "#238636", "✅ Instant"),
    "VW / Audi / Seat / Skoda": ("VW / Audi / Seat / Skoda", "🔵", "#D29922", "⚠️ DB lookup"),
    "Vauxhall / Opel":   ("Vauxhall / Opel",   "🔵", "#D29922", "⚠️ DB lookup"),
    "Fiat / Alfa Romeo": ("Fiat / Alfa Romeo",  "🟡", "#238636", "✅ Instant"),
    "Nissan":            ("Nissan",             "🔵", "#D29922", "⚠️ DB lookup"),
    "Honda":             ("Honda",              "🏁", "#1F6FEB", "🏁 FREE portal"),
    "Acura":             ("Acura",              "🏁", "#1F6FEB", "🏁 FREE portal"),
}

BRAND_HELP = {
    "Ford M-Series": "Enter serial starting with M (e.g. M025345)",
    "Ford V-Series": "Enter serial starting with V (e.g. V528803)",
    "Renault / Dacia": "Enter pre-code: 1 letter + 3 digits (e.g. D123)",
    "Kia": "Enter serial with letter + 3 digits (e.g. H050, B777, G598)",
    "VW / Audi / Seat / Skoda": "Enter full 14-char serial (e.g. VWZ5Z7B5013069)",
    "Vauxhall / Opel": "Enter serial starting with GM (e.g. GM020328268659)",
    "Fiat / Alfa Romeo": "Enter last 4 digits of serial (e.g. VP1-1234 → enter 1234)",
    "Nissan": "⚠️ Formula unverified. Try serial or use FREE portal: radio-navicode.nissan.com",
    "Honda": "🌐 OFFICIAL FREE: radio-navicode.honda.com — Enter VIN + radio serial",
    "Acura": "🌐 OFFICIAL FREE: radio-navicode.acura.com — Enter VIN + radio serial",
}

# Colours
BG = "#0D1117"
SURFACE = "#161B22"
CARD_BG = "#1C2128"
ACCENT = "#238636"
ACCENT2 = "#1F6FEB"
TEXT = "#E6EDF3"
TEXT_MUTED = "#7D8590"
BORDER = "#30363D"
RED = "#F85149"
GREEN = "#3FB950"
ORANGE = "#D29922"


# ── App ──────────────────────────────────────────────────────────────────
def main(page: Page):
    page.title = "RadioUnlock"
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 0
    page.spacing = 0
    page.navigation_bar = None

    # State
    selected_brand = ft.Ref[ft.Text]()
    brand_buttons = {}
    serial_input = ft.Ref[ft.TextField]()
    result_text = ft.Ref[ft.Text]()
    status_text = ft.Ref[ft.Text]()
    help_text = ft.Ref[ft.Text]()
    result_card = ft.Ref[ft.Container]()
    calc_button = ft.Ref[ft.ElevatedButton]()
    input_section = ft.Ref[ft.Container]()

    # ── Brand button factory ─────────────────────────────────────────────
    def make_brand_button(key):
        meta = BRAND_META.get(key, (key, "📻", "#7D8590", ""))
        label, emoji, color, note = meta
        btn = ft.Container(
            content=ft.Column([
                ft.Text(emoji, size=22),
                ft.Text(label, size=11, weight=ft.FontWeight.W_600, color=TEXT,
                        text_align=ft.TextAlign.CENTER),
                ft.Text(note, size=9, color=TEXT_MUTED, text_align=ft.TextAlign.CENTER),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=2),
            alignment=ft.alignment.center,
            padding=8,
            border_radius=12,
            bgcolor=SURFACE,
            border=ft.border.all(1, BORDER),
            on_click=lambda _, k=key: on_brand_select(k),
            expand=1,
        )
        brand_buttons[key] = btn
        return btn

    def on_brand_select(key):
        # Reset all buttons
        for k, btn in brand_buttons.items():
            meta = BRAND_META.get(k, (k, "📻", "#7D8590", ""))
            _, _, color, _ = meta
            btn.border = ft.border.all(1, BORDER)
            btn.bgcolor = SURFACE

        # Highlight selected
        btn = brand_buttons[key]
        _, _, color, _ = BRAND_META.get(key, (key, "📻", color, ""))
        btn.border = ft.border.all(2, color)
        btn.bgcolor = CARD_BG

        # Update help
        if help_text.current:
            help_text.current.value = BRAND_HELP.get(key, "")
            help_text.current.update()

        # Show input section
        if input_section.current:
            input_section.current.visible = True
            input_section.current.update()

        # Update selected brand label
        if selected_brand.current:
            selected_brand.current.value = key
            selected_brand.current.update()

        # Focus serial input
        if serial_input.current:
            serial_input.current.value = ""
            serial_input.current.update()
            serial_input.current.focus()

        # Hide result
        if result_card.current:
            result_card.current.visible = False
            result_card.current.update()

    # ── Input section (shown after brand selected) ───────────────────────
    serial_field = ft.TextField(
        ref=serial_input,
        label="Radio Serial Number",
        hint_text="Enter serial number...",
        bgcolor=SURFACE,
        border_color=BORDER,
        focused_border_color=ACCENT2,
        label_style=ft.TextStyle(color=TEXT_MUTED),
        text_style=ft.TextStyle(color=TEXT, size=18),
        visible=False,
        on_submit=lambda _: calculate() if calc_button.current else None,
    )

    def calculate():
        brand_key = selected_brand.current.value if selected_brand.current else None
        serial = serial_input.current.value or "" if serial_input.current else ""

        if not brand_key:
            page.show_snack_bar(ft.SnackBar(content=Text("⚠️ Select a brand first")))
            return
        if not serial.strip():
            page.show_snack_bar(ft.SnackBar(content=Text("⚠️ Enter a serial number")))
            return

        algo = ALGORITHMS.get(brand_key)
        if not algo:
            return

        is_valid, err = algo.validate_serial(serial.strip())
        if not is_valid:
            result_card.current.visible = True
            result_text.current.value = "???"
            result_text.current.color = RED
            status_text.current.value = f"Invalid serial: {err}"
            status_text.current.color = RED
            result_card.current.update()
            return

        try:
            code = algo.calculate(serial.strip())
            result_card.current.visible = True
            result_text.current.value = code
            result_text.current.color = GREEN
            status_text.current.value = f"✅ {brand_key} — Code found!"
            status_text.current.color = GREEN
            result_card.current.update()
        except ValueError as err:
            result_card.current.visible = True
            result_text.current.value = "NOT FOUND"
            result_text.current.color = TEXT_MUTED
            status_text.current.value = str(err)[:120]
            status_text.current.color = TEXT_MUTED
            result_card.current.update()

    def copy_code(_):
        code = result_text.current.value if result_text.current else ""
        if code and code not in ("——", "???", "NOT FOUND"):
            page.set_clipboard(code)
            page.show_snack_bar(ft.SnackBar(content=Text(f"📋 {code} copied!")))

    # ── Build brand grid ────────────────────────────────────────────────
    brand_keys = list(ALGORITHMS.keys())
    brand_rows = []
    for i in range(0, len(brand_keys), 3):
        row_keys = brand_keys[i:i+3]
        # Pad to 3
        while len(row_keys) < 3:
            row_keys.append(None)
        brand_rows.append(
            ft.Row(
                [make_brand_button(k) if k else ft.Container() for k in row_keys],
                spacing=8,
            )
        )

    # ── Input section container ─────────────────────────────────────────
    input_section_ctr = ft.Container(
        ref=input_section,
        visible=False,
        content=ft.Column([
            serial_field,
            ft.Container(height=12),
            ft.Container(
                ft.ElevatedButton(
                    ref=calc_button,
                    text="🔓 CALCULATE CODE",
                    on_click=calculate,
                    style=ft.ButtonStyle(
                        bgcolor=ACCENT, color=ft.WHITE, padding=14,
                        shape=ft.RoundedRectangleBorder(radius=12),
                    ),
                    width=700,
                ),
                alignment=ft.alignment.center,
            ),
        ], spacing=0),
    )

    result_card_ctr = ft.Container(
        ref=result_card,
        visible=False,
        content=ft.Column([
            ft.Text("——", ref=result_text, size=56, weight=ft.FontWeight.W_700,
                    font_family="monospace", color=TEXT, text_align=ft.TextAlign.CENTER),
            ft.Text("Enter serial and tap Calculate", ref=status_text,
                    size=12, color=TEXT_MUTED, text_align=ft.TextAlign.CENTER),
        ], alignment=ft.MainAxisAlignment.CENTER, spacing=4),
        padding=ft.padding.symmetric(vertical=30, horizontal=20),
        border_radius=16,
        bgcolor=CARD_BG,
        border=ft.border.all(1, BORDER),
    )

    # ── Home view ───────────────────────────────────────────────────────
    home_view = View(
        "/",
        [
            ft.Container(
                padding=16,
                bgcolor=BG,
                content=ft.Column(
                    [
                        # Header
                        ft.Row([
                            ft.Text("📻", size=28),
                            ft.Text("RadioUnlock", size=26, weight=ft.FontWeight.W_700, color=TEXT),
                        ], spacing=8),
                        ft.Text("Free car radio codes · No ads · No paywalls",
                                size=12, color=TEXT_MUTED),
                        ft.Container(height=16),

                        # Brand label
                        ft.Text("SELECT BRAND", size=11, weight=ft.FontWeight.W_700,
                                color=TEXT_MUTED, letter_spacing=1),
                        ft.Container(height=8),

                        # Brand grid
                        *brand_rows,

                        ft.Container(height=8),

                        # Selected brand
                        ft.Container(
                            ft.Text("", ref=selected_brand, size=13,
                                    color=ACCENT2, weight=ft.FontWeight.W_600),
                            alignment=ft.alignment.center,
                        ),

                        # Input section
                        input_section_ctr,

                        # Result
                        result_card_ctr,

                        # Copy button
                        ft.Container(
                            ft.ElevatedButton(
                                text="📋 Copy Code",
                                on_click=copy_code,
                                style=ft.ButtonStyle(
                                    bgcolor=CARD_BG, color=TEXT, padding=10,
                                    shape=ft.RoundedRectangleBorder(radius=8),
                                ),
                            ),
                            alignment=ft.alignment.center,
                            visible=True,
                        ),

                        # Help
                        ft.Container(
                            ft.Text("", ref=help_text, size=12,
                                    color=TEXT_MUTED, italic=True),
                            alignment=ft.alignment.center,
                            padding=ft.padding.symmetric(horizontal=20),
                        ),

                        ft.Container(height=16),

                        # DB badge
                        ft.Row([
                            ft.Text("🔍", size=14),
                            ft.Text(f"{DB_TOTAL}", size=16, weight=ft.FontWeight.W_700, color=GREEN),
                            ft.Text(f"free codes across {DB_BRANDS} brands",
                                    size=13, color=TEXT_MUTED),
                        ], alignment=ft.MainAxisAlignment.CENTER),
                    ],
                    scroll=ft.ScrollMode.AUTO,
                    spacing=0,
                ),
            ),
        ],
    )

    # ── EEPROM view ────────────────────────────────────────────────────
    eeprom_view = View(
        "/eeprom",
        [
            ft.Container(
                padding=16,
                bgcolor=BG,
                content=ft.Column(
                    [
                        ft.Row([
                            ft.Text("💾 EEPROM Reader", size=24, weight=ft.FontWeight.W_700, color=TEXT),
                        ]),
                        ft.Text("Extract code directly from radio's memory chip",
                                size=12, color=TEXT_MUTED),
                        ft.Container(height=16),

                        ft.Container(
                            padding=14,
                            border_radius=12,
                            bgcolor=CARD_BG,
                            border=ft.border.all(1, BORDER),
                            content=ft.Column([
                                ft.Text("📋 How to get your EEPROM dump:",
                                        size=14, weight=ft.FontWeight.W_600, color=TEXT),
                                ft.Container(height=8),
                                ft.Text("1️⃣ Remove radio from dashboard", size=13, color=TEXT),
                                ft.Text("2️⃣ Find the 8-pin SOIC chip (marked 24Cxx)", size=13, color=TEXT),
                                ft.Text("3️⃣ Solder to CH341A programmer (~£5)", size=13, color=TEXT),
                                ft.Text("4️⃣ Read with flashrom or CH341A software", size=13, color=TEXT),
                                ft.Text("5️⃣ Save as .bin — load in desktop app", size=13, color=TEXT),
                            ], spacing=6),
                        ),
                        ft.Container(height=12),

                        ft.Container(
                            padding=14,
                            border_radius=12,
                            bgcolor=CARD_BG,
                            border=ft.border.all(1, BORDER),
                            content=ft.Column([
                                ft.Text("📡 Supported EEPROM chips:",
                                        size=14, weight=ft.FontWeight.W_600, color=TEXT),
                                ft.Container(height=8),
                                ft.Text("24C01 · 24C02 · 24C04 · 24C08 · 24C16 · 24C64",
                                        size=13, color=ACCENT2, font_family="monospace"),
                                ft.Container(height=8),
                                ft.Text("Supported radios:", size=12, color=TEXT_MUTED),
                                ft.Text("Blaupunkt CAR2003/2004/300/CD300", size=12, color=TEXT_MUTED),
                                ft.Text("Siemens VDO CR500", size=12, color=TEXT_MUTED),
                                ft.Text("Ford 6000CD · M-Series", size=12, color=TEXT_MUTED),
                                ft.Text("Bosch Touch & Connect", size=12, color=TEXT_MUTED),
                                ft.Text("Renault · VW RCD · Nissan Connect", size=12, color=TEXT_MUTED),
                            ], spacing=4),
                        ),
                        ft.Container(height=12),

                        ft.Container(
                            padding=14,
                            border_radius=12,
                            bgcolor=CARD_BG,
                            border=ft.border.all(1, BORDER),
                            content=ft.Column([
                                ft.Text("🔧 Recommended programmer:",
                                        size=14, weight=ft.FontWeight.W_600, color=TEXT),
                                ft.Container(height=8),
                                ft.Text("CH341A USB programmer — ~£5 on eBay/Amazon", size=12, color=TEXT),
                                ft.Text("Works on Windows, macOS, Linux", size=12, color=TEXT),
                                ft.Text("Software: flashrom (free) or CH341A tool", size=12, color=TEXT),
                                ft.Container(height=8),
                                ft.Text("💡 The desktop app does full-chip BCD scan — finds codes "
                                        "even for unknown radio models",
                                        size=11, color=TEXT_MUTED, italic=True),
                            ], spacing=4),
                        ),
                    ],
                    scroll=ft.ScrollMode.AUTO,
                ),
            ),
        ],
    )

    # ── About view ─────────────────────────────────────────────────────
    about_view = View(
        "/about",
        [
            ft.Container(
                padding=16,
                bgcolor=BG,
                content=ft.Column(
                    [
                        ft.Row([
                            ft.Text("📻 RadioUnlock", size=24, weight=ft.FontWeight.W_700, color=TEXT),
                        ]),
                        ft.Text("Free car radio codes · No ads · No paywalls",
                                size=12, color=TEXT_MUTED),
                        ft.Container(height=16),

                        # Stats
                        ft.Container(
                            padding=20,
                            border_radius=16,
                            bgcolor=ACCENT,
                            content=ft.Row([
                                ft.Column([
                                    ft.Text(f"{DB_TOTAL}", size=42, weight=ft.FontWeight.W_700, color=ft.WHITE),
                                    ft.Text("free codes", size=13, color=ft.WHITE),
                                ]),
                                ft.Container(width=32),
                                ft.Column([
                                    ft.Text(f"{DB_BRANDS}", size=42, weight=ft.FontWeight.W_700, color=ft.WHITE),
                                    ft.Text("car brands", size=13, color=ft.WHITE),
                                ]),
                            ], spacing=16),
                        ),
                        ft.Container(height=16),

                        # Algos
                        ft.Container(
                            padding=14,
                            border_radius=12,
                            bgcolor=CARD_BG,
                            border=ft.border.all(1, BORDER),
                            content=ft.Column([
                                ft.Text("✅ Working algorithms (instant, no internet):",
                                        size=13, weight=ft.FontWeight.W_600, color=GREEN),
                                ft.Container(height=6),
                                ft.Text("Ford M-Series · Ford V-Series · Renault / Dacia",
                                        size=12, color=TEXT, font_family="monospace"),
                                ft.Text("Fiat / Alfa Romeo VP1/VP2 · Kia 10x10 table",
                                        size=12, color=TEXT, font_family="monospace"),
                                ft.Container(height=4),
                                ft.Text("⚠️ Database lookup (may not find your serial):",
                                        size=11, weight=ft.FontWeight.W_600, color=ORANGE),
                                ft.Text("VW/Audi/Seat/Skoda · Vauxhall/Opel · Nissan",
                                        size=12, color=TEXT),
                                ft.Container(height=4),
                                ft.Text("🏁 Free official portals (internet required):",
                                        size=11, weight=ft.FontWeight.W_600, color=ACCENT2),
                                ft.Text("Honda · Acura — radio-navicode.honda.com / acura.com",
                                        size=12, color=TEXT),
                            ], spacing=4),
                        ),
                        ft.Container(height=12),

                        # EEPROM info
                        ft.Container(
                            padding=14,
                            border_radius=12,
                            bgcolor=CARD_BG,
                            border=ft.border.all(1, BORDER),
                            content=ft.Column([
                                ft.Text("💾 EEPROM Reader",
                                        size=13, weight=ft.FontWeight.W_600, color=TEXT),
                                ft.Container(height=6),
                                ft.Text("If no algorithm matches your radio, extract the code "
                                        "directly from the radio's 24Cxx EEPROM chip using a "
                                        "CH341A programmer. Works for ALL radios regardless "
                                        "of brand or model.",
                                        size=12, color=TEXT_MUTED),
                            ], spacing=4),
                        ),
                        ft.Container(height=12),

                        # Sources
                        ft.Container(
                            padding=14,
                            border_radius=12,
                            bgcolor=CARD_BG,
                            border=ft.border.all(1, BORDER),
                            content=ft.Column([
                                ft.Text("📚 Algorithm sources:",
                                        size=13, weight=ft.FontWeight.W_600, color=TEXT),
                                ft.Container(height=6),
                                ft.Text("Ford M/V Series: GitHub gist (OlegSmelov)",
                                        size=11, color=TEXT_MUTED),
                                ft.Text("Renault: mark0wnik/VP1-VP2-Toolkit",
                                        size=11, color=TEXT_MUTED),
                                ft.Text("Fiat VP1/VP2: mark0wnik/VP1-VP2-Toolkit",
                                        size=11, color=TEXT_MUTED),
                                ft.Text("Kia: BluePill reverse-engineered (48-entry table)",
                                        size=11, color=TEXT_MUTED),
                                ft.Container(height=4),
                                ft.Text("🔓 Break the radio code racket forever.",
                                        size=12, color=GREEN, weight=ft.FontWeight.W_600),
                            ], spacing=4),
                        ),
                    ],
                    scroll=ft.ScrollMode.AUTO,
                ),
            ),
        ],
    )

    # ── Navigation ─────────────────────────────────────────────────────
    page.views.clear()
    page.views.append(home_view)
    page.views.append(eeprom_view)
    page.views.append(about_view)

    def on_view_pop(e):
        page.views.pop()
        page.update()

    page.on_view_pop = on_view_pop

    # Bottom nav
    page.navigation_bar = ft.NavigationBar(
        selected_index=0,
        bgcolor=SURFACE,
        indicator_color=ACCENT2,
        destinations=[
            ft.NavigationDestination(icon=ft.icons.CALCULATE, label="Calculator"),
            ft.NavigationDestination(icon=ft.icons.MEMORY, label="EEPROM"),
            ft.NavigationDestination(icon=ft.icons.INFO, label="About"),
        ],
        on_change=lambda e: (
            page.views.pop() if len(page.views) > 1 else None,
            page.views.append([home_view, eeprom_view, about_view][e.data]),
            page.update(),
        ),
    )
    page.update()
